#!/usr/bin/env bash
cd "$(dirname "$0")"
docker compose down
echo "Cabang pekalongan1 telah dimatikan."
read -p "Tekan [Enter] untuk keluar..."
