#!/usr/bin/env bash
open "https://vrsurft.vocpos.id"
