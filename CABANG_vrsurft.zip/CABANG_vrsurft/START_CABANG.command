#!/usr/bin/env bash
cd "$(dirname "$0")"
docker compose pull || true
docker compose up -d
sleep 3
open "http://localhost:3005"
