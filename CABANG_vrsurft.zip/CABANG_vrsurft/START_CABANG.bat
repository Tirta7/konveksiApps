@echo off
setlocal enabledelayedexpansion
title Menjalankan Cabang pekalongan1
color 0A
cls

:: 1. Self-Elevation Admin jika diperlukan
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process cmd.exe -ArgumentList '/c cd /d \"%~dp0\" && \"%~f0\" & pause' -Verb RunAs -Wait"
    exit /b 0
)

cd /d "%~dp0"

echo ============================================================
echo   SISTEM MANAJEMEN KONVEKSI - pekalongan1
echo ============================================================
echo.

:: 2. Cek Apakah Docker Terinstall
echo [1/4] Memeriksa status Docker Desktop...
docker --version >nul 2>&1
if not errorlevel 1 goto DOCKER_FOUND

echo.
echo  ============================================================
echo   [!] DOCKER DESKTOP BELUM TERPASANG DI KOMPUTER INI
echo   Memulai instalasi otomatis Docker Desktop...
echo   Proses ini membutuhkan waktu sekitar 5 - 15 menit.
echo  ============================================================
echo.

where winget >nul 2>&1
if not errorlevel 1 (
    echo  [..] Menginstall Docker via Windows Package Manager (winget)...
    winget install -e --id Docker.DockerDesktop --exact --source winget --silent --accept-package-agreements --accept-source-agreements
    if !errorlevel! equ 0 goto DOCKER_INSTALLED
    echo  [!] winget gagal, mencoba download langsung...
)

echo  [..] Mengunduh Docker Desktop Installer resmi...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -UserAgent 'Mozilla/5.0' -Uri 'https://desktop.docker.com/win/main/amd64/Docker%%20Desktop%%20Installer.exe' -OutFile '%TEMP%\DockerInstaller.exe'"

if not exist "%TEMP%\DockerInstaller.exe" (
    echo.
    echo  [ERROR] Gagal mengunduh Docker Desktop. Periksa koneksi internet Anda.
    pause
    exit /b 1
)

echo  [..] Memasang Docker Desktop (Silent Install)...
start /wait "" "%TEMP%\DockerInstaller.exe" install --quiet --accept-license --backend=wsl-2
del /q "%TEMP%\DockerInstaller.exe" >nul 2>&1

:DOCKER_INSTALLED
echo.
echo  ============================================================
echo   [BERHASIL] DOCKER DESKTOP TELAH DIINSTALL!
echo   ----------------------------------------------------------
echo   Komputer WAJIB di-RESTART sekarang agar WSL2 aktif.
echo   Setelah restart, silakan klik kembali file START_CABANG.bat!
echo  ============================================================
echo.
pause
exit /b 0

:DOCKER_FOUND
echo  [OK] Docker Desktop terpasang.

:: 3. Memastikan Docker Engine Berjalan
echo  [..] Memeriksa apakah Docker Engine aktif...
docker info >nul 2>&1
if not errorlevel 1 goto DOCKER_READY

echo  [!] Docker belum aktif. Membuka Docker Desktop otomatis...
if exist "C:\Program Files\Docker\Docker\Docker Desktop.exe" (
    start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe" >nul 2>&1
) else (
    start "" "Docker Desktop" >nul 2>&1
)

echo  Menunggu Docker Engine aktif (maksimal 90 detik)...
set /a attempt=0
:WAIT_DOCKER
timeout /t 5 /nobreak >nul
docker info >nul 2>&1
if %errorlevel% equ 0 goto DOCKER_READY
set /a attempt+=1
if !attempt! lss 18 (
    echo   ...menunggu Docker siap (!attempt!/18)...
    goto WAIT_DOCKER
)
echo.
echo  [ERROR] Docker Desktop belum aktif. Buka Docker Desktop secara manual
echo  hingga status 'Engine Running', lalu klik kembali file ini.
pause
exit /b 1

:DOCKER_READY
echo  [OK] Docker Engine aktif dan siap.

:: 4. Deteksi Hardware Machine ID
echo.
echo [2/4] Menyesuaikan Machine ID hardware komputer...
if exist "get-machine-id.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File get-machine-id.ps1 >nul 2>&1
)

:: 5. Login GHCR jika ada token
echo.
echo [3/4] Memeriksa kredensial update...
if exist ".token" (
    for /f "usebackq tokens=1,* delims==" %%a in (".token") do (
        if /i "%%a"=="GITHUB_USERNAME" set "GH_USER=%%b"
        if /i "%%a"=="GITHUB_TOKEN"    set "GH_PAT=%%b"
    )
    if defined GH_PAT (
        echo !GH_PAT! | docker login ghcr.io -u !GH_USER! --password-stdin >nul 2>&1
    )
)

:: 6. Jalankan Layanan
echo.
echo [4/4] Menjalankan server aplikasi pekalongan1...
docker compose pull
docker compose up -d

echo Menunggu inisialisasi server (5 detik)...
timeout /t 5 /nobreak >nul
start http://localhost:3005
start https://vrsurft.vocpos.id
