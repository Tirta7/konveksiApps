@echo off
setlocal enabledelayedexpansion
title Update Versi Terbaru Cabang pekalongan1
color 0E
cls

:: Self-Elevation Admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

cd /d "%~dp0"
echo ============================================================
echo   UPDATE APLIKASI KONVEKSI - pekalongan1
echo   Mengunduh fitur & pembaruan sistem dari cloud...
echo ============================================================
echo.

:: Cek Docker
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Membuka Docker Desktop...
    if exist "C:\Program Files\Docker\Docker\Docker Desktop.exe" start "" "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    timeout /t 15 /nobreak >nul
)

:: Login jika ada token
if exist ".token" (
    for /f "usebackq tokens=1,* delims==" %%a in (".token") do (
        if /i "%%a"=="GITHUB_USERNAME" set "GH_USER=%%b"
        if /i "%%a"=="GITHUB_TOKEN"    set "GH_PAT=%%b"
    )
    if defined GH_PAT echo !GH_PAT! | docker login ghcr.io -u !GH_USER! --password-stdin >nul 2>&1
)

echo [1/2] Mengunduh pembaruan dari cloud server (ghcr.io)...
docker compose pull

echo.
echo [2/2] Merestart kontainer dengan versi baru...
docker compose up -d --remove-orphans

echo.
echo [OK] Update selesai! Membuka aplikasi...
timeout /t 5 /nobreak >nul
start http://localhost:3005
start https://vrsurft.vocpos.id
pause

