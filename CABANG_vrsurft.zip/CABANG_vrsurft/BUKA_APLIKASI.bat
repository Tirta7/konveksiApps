@echo off
start https://vrsurft.vocpos.id
