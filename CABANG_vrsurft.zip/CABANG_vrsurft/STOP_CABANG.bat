@echo off
title Hentikan Cabang pekalongan1
cd /d "%~dp0"
docker compose down
echo Cabang pekalongan1 telah dihentikan.
pause
